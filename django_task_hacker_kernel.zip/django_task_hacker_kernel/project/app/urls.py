from django.urls import path
from .views import user_add, task_add, user_list, task_list, export_to_excel

urlpatterns = [
    path('user/add/', user_add, name='user_add'),
    path('task/add/', task_add, name='task_add'),
    path('users/', user_list, name='user_list'),
    path('tasks/', task_list, name='task_list'),
    path('export/', export_to_excel, name='export_to_excel'),
]
