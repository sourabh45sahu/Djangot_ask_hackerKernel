from django.shortcuts import render, redirect
from django.core.paginator import Paginator
from django.http import HttpResponse
from .forms import UserForm, TaskForm
from .models import User, Task
import csv
from openpyxl import Workbook
from django.http import HttpResponse

# Create your views here.
def user_add(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('user_list')
    else:
        form = UserForm()
    return render(request, 'app/user_add.html', {'form': form})

def task_add(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('task_list')
    else:
        form = TaskForm()
    return render(request, 'app/task_add.html', {'form': form})

def user_list(request):
    users = User.objects.all()
    paginator = Paginator(users, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'app/user_list.html', {'page_obj': page_obj})

def task_list(request):
    tasks = Task.objects.all()
    paginator = Paginator(tasks, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'app/task_list.html', {'page_obj': page_obj})

def export_to_excel(request):
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=users_tasks.xlsx'

    wb = Workbook()
    ws = wb.active
    ws.title = 'Users and Tasks'

    ws.append(['User ID', 'Name', 'Email', 'Mobile', 'Task Details', 'Task Type'])

    users = User.objects.all().prefetch_related('tasks')
    for user in users:
        for task in user.tasks.all():
            ws.append([user.id, user.name, user.email, user.mobile, task.task_details, task.task_type])

    wb.save(response)
    return response



